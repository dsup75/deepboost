"use client";

import { motion } from "framer-motion";

const STEPS = ["Strategy", "Content", "Design", "Publishing", "Engagement", "Analytics", "Optimization"];

export default function SocialSystem() {
  return (
    <section className="section-pad">
      <div className="container-max grid gap-14 lg:grid-cols-2 lg:items-center">
        <div>
          <p className="eyebrow">Social Media Management</p>
          <h2 className="mt-4 font-display text-4xl font-semibold leading-tight tracking-tight sm:text-5xl">
            Your social presence,
            <br />
            run like a system.
          </h2>
          <p className="mt-5 max-w-md text-muted">
            Every post moves through the same repeatable pipeline — from strategy to
            optimization — so growth compounds instead of resetting every month.
          </p>
        </div>

        <div className="relative">
          <div className="absolute left-4 top-0 h-full w-px bg-gradient-to-b from-violet via-cyan to-transparent" />
          <div className="space-y-3">
            {STEPS.map((step, i) => (
              <motion.div
                key={step}
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.06 }}
                className="relative ml-10 flex items-center gap-4 rounded-xl border border-border bg-card px-5 py-4"
              >
                <span className="absolute -left-[2.35rem] flex h-4 w-4 items-center justify-center rounded-full bg-gradient-violet-cyan" />
                <span className="text-sm font-medium">{step}</span>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

import type { Metadata } from "next";
import About from "@/components/sections/About";
import Process from "@/components/sections/Process";
import CTA from "@/components/sections/CTA";

export const metadata: Metadata = {
  title: "About",
  description:
    "DeepBoost brings creative production, performance marketing and digital strategy together to help ambitious brands grow with clarity and speed.",
};

export default function AboutPage() {
  return (
    <div className="pt-20">
      <About />
      <Process />
      <CTA />
    </div>
  );
}

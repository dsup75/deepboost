"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Search, Trash2 } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import type { ContactSubmission, InquiryStatus } from "@/types";

const STATUSES: InquiryStatus[] = ["New", "Contacted", "Qualified", "Converted", "Closed"];

export default function InquiriesPage() {
  const [items, setItems] = useState<ContactSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("All");
  const [sortDesc, setSortDesc] = useState(true);

  async function load() {
    setLoading(true);
    const supabase = createClient();
    const { data } = await supabase
      .from("contact_submissions")
      .select("*")
      .order("created_at", { ascending: !sortDesc });
    setItems((data as unknown as ContactSubmission[]) ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sortDesc]);

  async function updateStatus(id: string, status: InquiryStatus) {
    const supabase = createClient();
    await supabase.from("contact_submissions").update({ status }).eq("id", id);
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, status } : i)));
  }

  async function deleteInquiry(id: string) {
    if (!confirm("Delete this inquiry permanently?")) return;
    const supabase = createClient();
    await supabase.from("contact_submissions").delete().eq("id", id);
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  const filtered = useMemo(() => {
    return items.filter((i) => {
      const matchesSearch =
        !search ||
        [i.name, i.company, i.email].some((f) => f.toLowerCase().includes(search.toLowerCase()));
      const matchesStatus = statusFilter === "All" || i.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  }, [items, search, statusFilter]);

  return (
    <div className="p-6 md:p-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold">Inquiries</h1>
          <p className="mt-1 text-sm text-muted">Project requests submitted through the contact form.</p>
        </div>
      </div>

      <div className="mt-6 flex flex-wrap items-center gap-3">
        <div className="relative">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, company, email"
            className="rounded-lg border border-border bg-card py-2 pl-9 pr-3 text-sm outline-none focus:border-violet"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none focus:border-violet"
        >
          <option>All</option>
          {STATUSES.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
        <button
          onClick={() => setSortDesc((s) => !s)}
          className="rounded-lg border border-border px-3 py-2 text-sm text-muted hover:text-text"
        >
          {sortDesc ? "Newest first" : "Oldest first"}
        </button>
      </div>

      <div className="mt-6 overflow-x-auto rounded-xl border border-border">
        <table className="w-full text-left text-sm">
          <thead className="bg-bg-secondary text-muted">
            <tr>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Company</th>
              <th className="px-4 py-3 font-medium">Service</th>
              <th className="px-4 py-3 font-medium">Budget</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium" />
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-muted">
                  Loading...
                </td>
              </tr>
            ) : filtered.length === 0 ? (
              <tr>
                <td colSpan={6} className="px-4 py-8 text-center text-muted">
                  No inquiries match.
                </td>
              </tr>
            ) : (
              filtered.map((i) => (
                <tr key={i.id} className="border-t border-border">
                  <td className="px-4 py-3">
                    <Link href={`/admin/inquiries/${i.id}`} className="hover:text-cyan">
                      {i.name}
                    </Link>
                  </td>
                  <td className="px-4 py-3">{i.company}</td>
                  <td className="px-4 py-3">{i.service}</td>
                  <td className="px-4 py-3">{i.budget || "—"}</td>
                  <td className="px-4 py-3">
                    <select
                      value={i.status}
                      onChange={(e) => updateStatus(i.id, e.target.value as InquiryStatus)}
                      className="rounded-lg border border-border bg-card px-2 py-1 text-xs outline-none"
                    >
                      {STATUSES.map((s) => (
                        <option key={s}>{s}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-4 py-3 text-right">
                    <button
                      onClick={() => deleteInquiry(i.id)}
                      aria-label="Delete inquiry"
                      className="text-muted hover:text-red-400"
                    >
                      <Trash2 size={15} />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

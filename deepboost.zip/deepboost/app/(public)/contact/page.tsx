import type { Metadata } from "next";
import { Mail } from "lucide-react";
import ContactForm from "@/components/forms/ContactForm";

export const metadata: Metadata = {
  title: "Contact",
  description: "Start a project with DeepBoost — tell us what you're building.",
};

export default function ContactPage() {
  return (
    <div className="section-pad pt-32">
      <div className="container-max grid gap-14 lg:grid-cols-[1fr_1.3fr]">
        <div>
          <p className="eyebrow">Contact</p>
          <h1 className="mt-4 font-display text-4xl font-semibold leading-tight tracking-tight sm:text-5xl">
            Ready to build your
            <br />
            next growth story?
          </h1>
          <p className="mt-5 max-w-sm text-muted">
            Tell us what you&apos;re building. We&apos;ll figure out how to make it grow.
          </p>
          <a
            href="mailto:deepboost1@gmail.com"
            className="mt-8 flex w-fit items-center gap-2 text-sm text-text/90 hover:text-text"
          >
            <Mail size={16} /> deepboost1@gmail.com
          </a>
        </div>

        <div className="card-surface p-6 sm:p-10">
          <ContactForm />
        </div>
      </div>
    </div>
  );
}

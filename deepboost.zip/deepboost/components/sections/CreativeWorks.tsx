"use client";

import { useState } from "react";
import Image from "next/image";
import { motion, AnimatePresence } from "framer-motion";
import type { CreativeWork, CreativeWorkCategory } from "@/types";

const CATEGORIES: (CreativeWorkCategory | "All")[] = [
  "All",
  "Social Media",
  "Ads",
  "Posters",
  "Branding",
  "Campaigns",
];

export default function CreativeWorks({ works }: { works: CreativeWork[] }) {
  const [active, setActive] = useState<(CreativeWorkCategory | "All")>("All");
  const filtered = active === "All" ? works : works.filter((w) => w.category === active);

  if (works.length === 0) return null;

  return (
    <section className="section-pad border-t border-border bg-bg-secondary">
      <div className="container-max">
        <div className="max-w-xl">
          <p className="eyebrow">Creative Works</p>
          <h2 className="mt-4 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
            Ideas, built to stop the scroll.
          </h2>
        </div>

        <div className="mt-8 flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c}
              onClick={() => setActive(c)}
              className={`rounded-full border px-4 py-2 text-sm transition-colors ${
                active === c
                  ? "border-transparent bg-text text-bg"
                  : "border-border text-muted hover:text-text"
              }`}
            >
              {c}
            </button>
          ))}
        </div>

        <div className="mt-10 columns-1 gap-6 sm:columns-2 lg:columns-3">
          <AnimatePresence mode="popLayout">
            {filtered.map((work) => (
              <motion.div
                key={work.id}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="group relative mb-6 break-inside-avoid overflow-hidden rounded-2xl border border-border"
              >
                <div className="relative aspect-square w-full">
                  <Image
                    src={work.image_url}
                    alt={work.title}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                </div>
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-bg/95 to-transparent p-4 opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                  <p className="text-xs uppercase tracking-wide text-cyan">{work.category}</p>
                  <p className="mt-1 font-medium">{work.title}</p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

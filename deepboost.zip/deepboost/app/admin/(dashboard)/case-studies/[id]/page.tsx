"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { TextField, TextAreaField, ToggleField } from "@/components/admin/FormField";
import type { CaseStudy, CaseStudyMetrics } from "@/types";

const EMPTY: Omit<CaseStudy, "id" | "created_at" | "updated_at"> = {
  client_name: "",
  industry: "",
  project_title: "",
  slug: "",
  challenge: "",
  strategy: "",
  execution: "",
  results: "",
  key_learnings: "",
  metrics: {},
  cover_image_url: "",
  gallery_image_urls: [],
  tags: [],
  featured: false,
  published: false,
};

const METRIC_KEYS: (keyof CaseStudyMetrics)[] = [
  "ad_spend",
  "impressions",
  "reach",
  "clicks",
  "ctr",
  "leads",
  "conversions",
  "cpl",
];

function slugify(input: string) {
  return input.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export default function CaseStudyEditPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const isNew = params.id === "new";

  const [form, setForm] = useState(EMPTY);
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (isNew) return;
    async function load() {
      const supabase = createClient();
      const { data } = await supabase.from("case_studies").select("*").eq("id", params.id).single();
      if (data) setForm(data as unknown as CaseStudy);
      setLoading(false);
    }
    load();
  }, [isNew, params.id]);

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function setMetric(key: keyof CaseStudyMetrics, value: string) {
    setForm((f) => ({ ...f, metrics: { ...f.metrics, [key]: value } }));
  }

  async function handleSave(publish?: boolean) {
    setSaving(true);
    const supabase = createClient();
    const payload = {
      ...form,
      slug: form.slug || slugify(form.project_title),
      published: publish ?? form.published,
    };

    if (isNew) {
      const { data, error } = await supabase.from("case_studies").insert(payload).select().single();
      setSaving(false);
      if (!error && data) router.push(`/admin/case-studies/${data.id}`);
    } else {
      await supabase.from("case_studies").update(payload).eq("id", params.id);
      setSaving(false);
      setForm(payload);
    }
  }

  async function handleDelete() {
    if (isNew || !confirm("Delete this case study permanently?")) return;
    const supabase = createClient();
    await supabase.from("case_studies").delete().eq("id", params.id);
    router.push("/admin/case-studies");
  }

  if (loading) return <div className="p-10 text-muted">Loading...</div>;

  return (
    <div className="p-6 md:p-10">
      <Link href="/admin/case-studies" className="text-sm text-muted hover:text-text">
        ← All Case Studies
      </Link>

      <h1 className="mt-4 font-display text-2xl font-semibold">
        {isNew ? "New Case Study" : form.project_title}
      </h1>

      <div className="mt-6 grid gap-8 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-5">
          <div className="grid gap-5 sm:grid-cols-2">
            <TextField label="Client Name" value={form.client_name} onChange={(v) => set("client_name", v)} required />
            <TextField label="Industry" value={form.industry} onChange={(v) => set("industry", v)} required />
          </div>
          <TextField label="Project Title" value={form.project_title} onChange={(v) => set("project_title", v)} required />
          <TextField label="Slug" value={form.slug} onChange={(v) => set("slug", v)} placeholder="auto-generated from title if left blank" />
          <TextField label="Cover Image URL" value={form.cover_image_url} onChange={(v) => set("cover_image_url", v)} />
          <TextAreaField label="Challenge" value={form.challenge} onChange={(v) => set("challenge", v)} />
          <TextAreaField label="Strategy" value={form.strategy} onChange={(v) => set("strategy", v)} />
          <TextAreaField label="Execution" value={form.execution} onChange={(v) => set("execution", v)} />
          <TextAreaField label="Results" value={form.results} onChange={(v) => set("results", v)} />
          <TextAreaField label="Key Learnings" value={form.key_learnings} onChange={(v) => set("key_learnings", v)} />

          <div>
            <p className="mb-3 text-sm text-muted">Metrics</p>
            <div className="grid gap-4 sm:grid-cols-2">
              {METRIC_KEYS.map((k) => (
                <TextField
                  key={k}
                  label={k.replace("_", " ").toUpperCase()}
                  value={form.metrics[k] ?? ""}
                  onChange={(v) => setMetric(k, v)}
                />
              ))}
            </div>
          </div>
        </div>

        <div className="space-y-5">
          <div className="card-surface space-y-4 p-5">
            <ToggleField label="Featured" value={form.featured} onChange={(v) => set("featured", v)} />
            <ToggleField label="Published" value={form.published} onChange={(v) => set("published", v)} />
          </div>

          <div className="flex flex-col gap-3">
            <button onClick={() => handleSave()} disabled={saving} className="btn-outline justify-center">
              {saving ? "Saving..." : "Save Draft"}
            </button>
            <button onClick={() => handleSave(true)} disabled={saving} className="btn-primary justify-center">
              {saving ? "Saving..." : form.published ? "Update" : "Publish"}
            </button>
            {!isNew && (
              <button
                onClick={handleDelete}
                className="rounded-full border border-red-500/30 px-6 py-3 text-sm font-semibold text-red-400 hover:bg-red-500/10"
              >
                Delete
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

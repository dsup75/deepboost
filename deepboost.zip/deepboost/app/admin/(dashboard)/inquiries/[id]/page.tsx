"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useParams } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import type { ContactSubmission, InquiryStatus } from "@/types";

const STATUSES: InquiryStatus[] = ["New", "Contacted", "Qualified", "Converted", "Closed"];

export default function InquiryDetailPage() {
  const params = useParams<{ id: string }>();
  const [item, setItem] = useState<ContactSubmission | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      const supabase = createClient();
      const { data } = await supabase
        .from("contact_submissions")
        .select("*")
        .eq("id", params.id)
        .single();
      setItem((data as unknown as ContactSubmission) ?? null);
      setLoading(false);
    }
    load();
  }, [params.id]);

  async function updateStatus(status: InquiryStatus) {
    if (!item) return;
    const supabase = createClient();
    await supabase.from("contact_submissions").update({ status }).eq("id", item.id);
    setItem({ ...item, status });
  }

  if (loading) return <div className="p-10 text-muted">Loading...</div>;
  if (!item) return <div className="p-10 text-muted">Inquiry not found.</div>;

  const fields: [string, string | null][] = [
    ["Name", item.name],
    ["Company", item.company],
    ["Email", item.email],
    ["Phone", item.phone],
    ["Country", item.country],
    ["Service", item.service],
    ["Budget", item.budget],
    ["Submitted", new Date(item.created_at).toLocaleString()],
  ];

  return (
    <div className="p-6 md:p-10">
      <Link href="/admin/inquiries" className="text-sm text-muted hover:text-text">
        ← All Inquiries
      </Link>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
        <h1 className="font-display text-2xl font-semibold">{item.name}</h1>
        <select
          value={item.status}
          onChange={(e) => updateStatus(e.target.value as InquiryStatus)}
          className="rounded-lg border border-border bg-card px-3 py-2 text-sm outline-none"
        >
          {STATUSES.map((s) => (
            <option key={s}>{s}</option>
          ))}
        </select>
      </div>

      <div className="mt-6 grid gap-4 sm:grid-cols-2">
        {fields.map(([label, value]) => (
          <div key={label} className="card-surface p-4">
            <p className="text-xs uppercase tracking-wide text-muted">{label}</p>
            <p className="mt-1 text-sm">{value || "—"}</p>
          </div>
        ))}
      </div>

      <div className="card-surface mt-6 p-6">
        <p className="text-xs uppercase tracking-wide text-muted">Project Details</p>
        <p className="mt-2 whitespace-pre-wrap text-sm leading-relaxed">{item.project_details}</p>
      </div>
    </div>
  );
}

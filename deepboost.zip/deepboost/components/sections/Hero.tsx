"use client";

import { motion } from "framer-motion";
import Link from "next/link";
import Hero3D from "@/components/3d/Hero3D";

const CAPABILITIES = ["Performance Marketing", "Creative Production", "Social Media", "Digital Growth"];

export default function Hero() {
  return (
    <section className="relative overflow-hidden pt-36 pb-16 md:pt-44 md:pb-24">
      <div className="grid-bg absolute inset-0 -z-10" />
      <div className="absolute left-1/2 top-0 -z-10 h-[600px] w-[900px] -translate-x-1/2 rounded-full bg-violet/20 blur-[160px]" />

      <div className="container-max grid gap-12 px-6 md:px-10 lg:grid-cols-2 lg:gap-8 lg:px-16">
        <div>
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="eyebrow mb-6"
          >
            DeepBoost — Creative &amp; Digital Growth Agency
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="font-display text-5xl font-semibold leading-[1.05] tracking-tight sm:text-6xl lg:text-7xl"
          >
            WE BUILD.
            <br />
            WE CREATE.
            <br />
            <span className="bg-gradient-violet-cyan bg-clip-text text-transparent">WE GROW.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.2 }}
            className="mt-7 max-w-lg text-lg text-muted"
          >
            Creative systems and performance strategies built to turn attention into
            measurable growth.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 0.3 }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <Link href="/contact" className="btn-primary">
              Start a Project <span aria-hidden>→</span>
            </Link>
            <Link href="#services" className="btn-outline">
              Explore Our Work <span aria-hidden>↓</span>
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, delay: 0.5 }}
            className="mt-14 flex flex-wrap gap-x-6 gap-y-3"
          >
            {CAPABILITIES.map((c) => (
              <span key={c} className="flex items-center gap-2 text-sm text-muted">
                <span className="h-1.5 w-1.5 rounded-full bg-cyan" />
                {c}
              </span>
            ))}
          </motion.div>
        </div>

        <div className="relative h-[380px] sm:h-[460px] lg:h-[560px]">
          <Hero3D />
        </div>
      </div>
    </section>
  );
}

"use client";

import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { ArrowUpRight, Target, Palette, Share2, TrendingUp, Layers, LucideIcon } from "lucide-react";
import type { Service } from "@/types";

const ICONS: Record<string, LucideIcon> = {
  target: Target,
  palette: Palette,
  share2: Share2,
  "trending-up": TrendingUp,
  layers: Layers,
};

function ServiceCard({ service, index }: { service: Service; index: number }) {
  const ref = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const Icon = ICONS[service.icon] ?? Target;

  function handleMove(e: React.MouseEvent<HTMLDivElement>) {
    const el = ref.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ x: py * -8, y: px * 8 });
  }

  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.08, duration: 0.5 }}
      onMouseMove={handleMove}
      onMouseLeave={() => setTilt({ x: 0, y: 0 })}
      style={{ transform: `perspective(900px) rotateX(${tilt.x}deg) rotateY(${tilt.y}deg)` }}
      className="group card-surface relative overflow-hidden p-8 transition-transform duration-200 ease-out"
    >
      <div className="pointer-events-none absolute -right-16 -top-16 h-48 w-48 rounded-full bg-gradient-violet-cyan opacity-0 blur-3xl transition-opacity duration-500 group-hover:opacity-20" />

      <div className="flex items-start justify-between">
        <span className="font-display text-sm text-muted">
          {String(index + 1).padStart(2, "0")}
        </span>
        <ArrowUpRight
          size={18}
          className="text-muted transition-all duration-300 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-cyan"
        />
      </div>

      <div className="mt-6 flex h-12 w-12 items-center justify-center rounded-xl bg-gradient-violet-cyan">
        <Icon size={22} className="text-bg" />
      </div>

      <h3 className="mt-6 font-display text-xl font-semibold">{service.name}</h3>
      <p className="mt-3 text-sm leading-relaxed text-muted">{service.description}</p>

      <ul className="mt-6 flex flex-wrap gap-2">
        {service.features.slice(0, 4).map((f) => (
          <li
            key={f}
            className="rounded-full border border-border px-3 py-1 text-xs text-muted"
          >
            {f}
          </li>
        ))}
      </ul>
    </motion.div>
  );
}

export default function Services({ services }: { services: Service[] }) {
  return (
    <section id="services" className="section-pad">
      <div className="container-max">
        <div className="max-w-xl">
          <p className="eyebrow">What We Do</p>
          <h2 className="mt-4 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
            Creative thinking meets measurable growth.
          </h2>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service, i) => (
            <ServiceCard key={service.id} service={service} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import type { Metric } from "@/types";

function AnimatedValue({ value }: { value: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [display, setDisplay] = useState("0");

  // Extract a leading numeric portion (handles "₹3.1L+", "1,254+", "1.78M+")
  const match = value.match(/^([^\d]*)([\d.,]+)(.*)$/);
  const prefix = match?.[1] ?? "";
  const numeric = match ? parseFloat(match[2].replace(/,/g, "")) : NaN;
  const suffix = match?.[3] ?? "";

  useEffect(() => {
    if (!inView) return;
    if (Number.isNaN(numeric)) {
      setDisplay(value);
      return;
    }
    const duration = 1400;
    const start = performance.now();
    const step = (now: number) => {
      const progress = Math.min((now - start) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      const current = numeric * eased;
      const formatted = numeric % 1 === 0 ? Math.round(current).toLocaleString() : current.toFixed(1);
      setDisplay(`${prefix}${formatted}${suffix}`);
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [inView, numeric, prefix, suffix, value]);

  return <span ref={ref}>{display}</span>;
}

export default function Metrics({ metrics }: { metrics: Metric[] }) {
  return (
    <section className="section-pad border-y border-border bg-bg-secondary">
      <div className="container-max grid grid-cols-2 gap-8 md:grid-cols-4 md:gap-6">
        {metrics.map((m, i) => (
          <motion.div
            key={m.id}
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.08, duration: 0.5 }}
            className="text-center md:text-left"
          >
            <div className="font-display text-4xl font-semibold tracking-tight sm:text-5xl">
              <AnimatedValue value={m.value} />
            </div>
            <p className="mt-2 text-xs uppercase tracking-[0.15em] text-muted">{m.label}</p>
          </motion.div>
        ))}
      </div>
    </section>
  );
}

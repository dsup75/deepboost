import { NextRequest, NextResponse } from "next/server";
import { z } from "zod";
import { resend } from "@/lib/resend";
import { createServiceClient } from "@/lib/supabase/server";

export const runtime = "nodejs";

const contactSchema = z.object({
  name: z.string().trim().min(2).max(120),
  company: z.string().trim().min(1).max(160),
  email: z.string().trim().email().max(200),
  phone: z.string().trim().max(40).optional().or(z.literal("")),
  country: z.string().trim().max(80).optional().or(z.literal("")),
  service: z.string().trim().min(1).max(120),
  budget: z.string().trim().max(60).optional().or(z.literal("")),
  projectDetails: z.string().trim().min(10).max(4000),
  website: z.string().max(0).optional().or(z.literal("")), // honeypot — must stay empty
});

// Simple in-memory sliding-window rate limiter.
// Fine for a single Vercel instance; swap for Upstash/Redis at scale.
const RATE_LIMIT_WINDOW_MS = 10 * 60 * 1000; // 10 minutes
const RATE_LIMIT_MAX = 5;
const hits = new Map<string, number[]>();

function isRateLimited(ip: string): boolean {
  const now = Date.now();
  const timestamps = (hits.get(ip) ?? []).filter((t) => now - t < RATE_LIMIT_WINDOW_MS);
  timestamps.push(now);
  hits.set(ip, timestamps);
  return timestamps.length > RATE_LIMIT_MAX;
}

function escapeHtml(input: string): string {
  return input
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get("x-forwarded-for")?.split(",")[0]?.trim() || "unknown";
    if (isRateLimited(ip)) {
      return NextResponse.json(
        { error: "Too many requests. Please try again later." },
        { status: 429 }
      );
    }

    const json = await req.json();
    const parsed = contactSchema.safeParse(json);

    if (!parsed.success) {
      return NextResponse.json(
        { error: "Please check the form fields and try again." },
        { status: 400 }
      );
    }

    const data = parsed.data;

    // Honeypot tripped — silently pretend success so bots don't learn.
    if (data.website) {
      return NextResponse.json({ ok: true });
    }

    // Persist to Supabase (public insert is allowed by RLS policy)
    try {
      const supabase = createServiceClient();
      await supabase.from("contact_submissions").insert({
        name: data.name,
        company: data.company,
        email: data.email,
        phone: data.phone || null,
        country: data.country || null,
        service: data.service,
        budget: data.budget || null,
        project_details: data.projectDetails,
      });
    } catch (dbError) {
      console.error("Supabase insert failed:", dbError);
      // Continue — we still want to attempt the email even if DB write fails.
    }

    const toEmail = process.env.CONTACT_TO_EMAIL || "deepboost1@gmail.com";
    const fromEmail = process.env.CONTACT_FROM_EMAIL || "onboarding@resend.dev";

    await resend.emails.send({
      from: `DeepBoost Website <${fromEmail}>`,
      to: toEmail,
      replyTo: data.email,
      subject: `New DeepBoost Project Inquiry — ${data.company}`,
      html: `
        <div style="font-family: sans-serif; max-width: 560px; margin: 0 auto;">
          <h2 style="margin-bottom: 4px;">New Project Inquiry</h2>
          <p style="color:#666; margin-top:0;">Submitted ${new Date().toLocaleString("en-US", {
            timeZone: "UTC",
          })} UTC</p>
          <table style="width:100%; border-collapse: collapse;">
            ${[
              ["Name", data.name],
              ["Company", data.company],
              ["Email", data.email],
              ["Phone", data.phone || "—"],
              ["Country", data.country || "—"],
              ["Service", data.service],
              ["Budget", data.budget || "—"],
            ]
              .map(
                ([label, value]) => `
              <tr>
                <td style="padding:8px 0; border-bottom:1px solid #eee; color:#666; width:140px;">${escapeHtml(
                  label
                )}</td>
                <td style="padding:8px 0; border-bottom:1px solid #eee;">${escapeHtml(String(value))}</td>
              </tr>`
              )
              .join("")}
          </table>
          <h3 style="margin-top:24px;">Project Details</h3>
          <p style="white-space: pre-wrap; line-height:1.6;">${escapeHtml(data.projectDetails)}</p>
        </div>
      `,
    });

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error("Contact form error:", err);
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 }
    );
  }
}

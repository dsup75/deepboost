import type { MetadataRoute } from "next";
import { getCaseStudies } from "@/lib/data";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://deepboost.com";
  const caseStudies = await getCaseStudies();

  const staticRoutes = ["", "/services", "/work", "/about", "/contact"].map((path) => ({
    url: `${siteUrl}${path}`,
    lastModified: new Date(),
  }));

  const caseStudyRoutes = caseStudies.map((cs) => ({
    url: `${siteUrl}/work/${cs.slug}`,
    lastModified: cs.updated_at ? new Date(cs.updated_at) : new Date(),
  }));

  return [...staticRoutes, ...caseStudyRoutes];
}

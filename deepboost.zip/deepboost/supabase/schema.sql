-- =========================================================
-- DEEPBOOST — Supabase schema
-- Run this in the Supabase SQL editor on a fresh project.
-- =========================================================

create extension if not exists "uuid-ossp";

-- ---------------------------------------------------------
-- profiles (admin users)
-- ---------------------------------------------------------
create table if not exists profiles (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text,
  role text not null default 'admin' check (role in ('admin', 'super_admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- case_studies
-- ---------------------------------------------------------
create table if not exists case_studies (
  id uuid primary key default uuid_generate_v4(),
  client_name text not null,
  industry text not null,
  project_title text not null,
  slug text not null unique,
  challenge text not null default '',
  strategy text not null default '',
  execution text not null default '',
  results text not null default '',
  key_learnings text not null default '',
  metrics jsonb not null default '{}'::jsonb,
  cover_image_url text not null default '',
  gallery_image_urls text[] not null default '{}',
  tags text[] not null default '{}',
  featured boolean not null default false,
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists case_studies_published_idx on case_studies (published, featured);

-- ---------------------------------------------------------
-- creative_works
-- ---------------------------------------------------------
create table if not exists creative_works (
  id uuid primary key default uuid_generate_v4(),
  title text not null,
  slug text not null unique,
  category text not null check (category in ('Social Media', 'Ads', 'Posters', 'Branding', 'Campaigns')),
  description text not null default '',
  image_url text not null default '',
  additional_image_urls text[] not null default '{}',
  tags text[] not null default '{}',
  featured boolean not null default false,
  published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists creative_works_published_idx on creative_works (published, category);

-- ---------------------------------------------------------
-- services
-- ---------------------------------------------------------
create table if not exists services (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  slug text not null unique,
  description text not null default '',
  features text[] not null default '{}',
  icon text not null default 'sparkles',
  visual_3d text,
  "order" int not null default 0,
  featured boolean not null default true,
  published boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- metrics (homepage animated counters)
-- ---------------------------------------------------------
create table if not exists metrics (
  id uuid primary key default uuid_generate_v4(),
  key text not null unique,
  label text not null,
  value text not null,
  "order" int not null default 0,
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- media library (external URLs for now)
-- ---------------------------------------------------------
create table if not exists media (
  id uuid primary key default uuid_generate_v4(),
  url text not null,
  title text not null default '',
  alt_text text not null default '',
  category text not null default 'general',
  created_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- site_settings (single row)
-- ---------------------------------------------------------
create table if not exists site_settings (
  id uuid primary key default uuid_generate_v4(),
  company_name text not null default 'DeepBoost',
  contact_email text not null default 'deepboost1@gmail.com',
  cta_text text not null default 'Start a Project',
  footer_text text not null default '© DeepBoost. All rights reserved.',
  social_links jsonb not null default '{}'::jsonb,
  seo_title text not null default 'DeepBoost — Creative & Digital Growth Agency',
  seo_description text not null default 'DeepBoost is a global creative and digital growth agency specializing in performance marketing, creative production, social media management and digital growth.',
  updated_at timestamptz not null default now()
);

-- ---------------------------------------------------------
-- contact_submissions
-- ---------------------------------------------------------
create table if not exists contact_submissions (
  id uuid primary key default uuid_generate_v4(),
  name text not null,
  company text not null,
  email text not null,
  phone text,
  country text,
  service text not null,
  budget text,
  project_details text not null,
  status text not null default 'New' check (status in ('New', 'Contacted', 'Qualified', 'Converted', 'Closed')),
  created_at timestamptz not null default now()
);

create index if not exists contact_submissions_status_idx on contact_submissions (status, created_at desc);

-- =========================================================
-- ROW LEVEL SECURITY
-- =========================================================

alter table profiles enable row level security;
alter table case_studies enable row level security;
alter table creative_works enable row level security;
alter table services enable row level security;
alter table metrics enable row level security;
alter table media enable row level security;
alter table site_settings enable row level security;
alter table contact_submissions enable row level security;

-- Helper: is the current user an authenticated admin?
create or replace function is_admin()
returns boolean
language sql
security definer
stable
as $$
  select exists (
    select 1 from profiles where id = auth.uid()
  );
$$;

-- profiles: admins can read their own row
create policy "profiles_select_own" on profiles
  for select using (auth.uid() = id);

-- case_studies: public reads published only; admins do everything
create policy "case_studies_public_read" on case_studies
  for select using (published = true);
create policy "case_studies_admin_all" on case_studies
  for all using (is_admin()) with check (is_admin());

-- creative_works
create policy "creative_works_public_read" on creative_works
  for select using (published = true);
create policy "creative_works_admin_all" on creative_works
  for all using (is_admin()) with check (is_admin());

-- services
create policy "services_public_read" on services
  for select using (published = true);
create policy "services_admin_all" on services
  for all using (is_admin()) with check (is_admin());

-- metrics: publicly readable (no draft state), admin-writable
create policy "metrics_public_read" on metrics
  for select using (true);
create policy "metrics_admin_write" on metrics
  for insert with check (is_admin());
create policy "metrics_admin_update" on metrics
  for update using (is_admin()) with check (is_admin());
create policy "metrics_admin_delete" on metrics
  for delete using (is_admin());

-- media: admin only (internal library)
create policy "media_admin_all" on media
  for all using (is_admin()) with check (is_admin());

-- site_settings: publicly readable, admin-writable
create policy "site_settings_public_read" on site_settings
  for select using (true);
create policy "site_settings_admin_update" on site_settings
  for update using (is_admin()) with check (is_admin());

-- contact_submissions: public can INSERT only; only admins can SELECT
create policy "contact_submissions_public_insert" on contact_submissions
  for insert with check (true);
create policy "contact_submissions_admin_select" on contact_submissions
  for select using (is_admin());
create policy "contact_submissions_admin_update" on contact_submissions
  for update using (is_admin()) with check (is_admin());
create policy "contact_submissions_admin_delete" on contact_submissions
  for delete using (is_admin());

-- =========================================================
-- SEED DATA (verified metrics only — edit freely in /admin)
-- =========================================================

insert into site_settings (company_name, contact_email)
values ('DeepBoost', 'deepboost1@gmail.com')
on conflict do nothing;

insert into metrics (key, label, value, "order") values
  ('ad_spend', 'AD SPEND MANAGED', '₹3.1L+', 1),
  ('leads', 'LEADS GENERATED', '1,254+', 2),
  ('reach', 'REACH', '1.78M+', 3),
  ('campaigns', 'CAMPAIGNS', '6+', 4)
on conflict (key) do nothing;

insert into services (name, slug, description, features, icon, "order") values
  ('Performance Marketing', 'performance-marketing',
   'Meta Ads strategy, targeting and optimization built around measurable growth.',
   array['Meta Ads','Lead Generation','Campaign Strategy','Audience Targeting','Creative Testing','Optimization','Conversion Tracking'],
   'target', 1),
  ('Creative Maker', 'creative-maker',
   'Ad and social creatives designed to stop the scroll and convert attention.',
   array['Social Media Creatives','Ad Creatives','Posters','Campaign Designs','Promotional Graphics','Brand Creatives','AI-assisted Creative Production'],
   'palette', 2),
  ('Social Media Management', 'social-media-management',
   'Full-funnel social operations from strategy through analytics.',
   array['Instagram Management','Facebook Management','Content Strategy','Content Calendar','Publishing & Scheduling','Community Engagement','Analytics & Reporting'],
   'share2', 3),
  ('Digital Growth', 'digital-growth',
   'Funnels and reporting systems built to compound performance over time.',
   array['Growth Strategy','Marketing Funnels','Conversion Optimization','Analytics','Performance Reporting','Digital Campaigns'],
   'trending-up', 4),
  ('Brand & Content', 'brand-content',
   'Visual identity and content systems that keep every channel consistent.',
   array['Visual Identity','Campaign Concepts','Content Systems','Brand Communication','Creative Direction'],
   'layers', 5)
on conflict (slug) do nothing;

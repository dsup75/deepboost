import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { getCaseStudyBySlug } from "@/lib/data";

export async function generateMetadata({
  params,
}: {
  params: { slug: string };
}): Promise<Metadata> {
  const caseStudy = await getCaseStudyBySlug(params.slug);
  if (!caseStudy) return {};
  return {
    title: caseStudy.project_title,
    description: caseStudy.results || caseStudy.challenge,
  };
}

const METRIC_LABELS: Record<string, string> = {
  ad_spend: "Ad Spend",
  impressions: "Impressions",
  reach: "Reach",
  clicks: "Clicks",
  ctr: "CTR",
  leads: "Leads",
  conversions: "Conversions",
  cpl: "CPL",
};

export default async function CaseStudyPage({ params }: { params: { slug: string } }) {
  const caseStudy = await getCaseStudyBySlug(params.slug);
  if (!caseStudy) notFound();

  const metricEntries = Object.entries(caseStudy.metrics || {}).filter(([, v]) => v);

  return (
    <article className="pt-32">
      <div className="container-max px-6 md:px-10 lg:px-16">
        <Link href="/work" className="text-sm text-muted hover:text-text">
          ← All Work
        </Link>

        <div className="mt-6 max-w-2xl">
          <p className="eyebrow">{caseStudy.industry}</p>
          <h1 className="mt-4 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
            {caseStudy.project_title}
          </h1>
          <p className="mt-3 text-muted">{caseStudy.client_name}</p>
        </div>

        <div className="relative mt-10 aspect-[16/8] w-full overflow-hidden rounded-2xl border border-border">
          <Image src={caseStudy.cover_image_url} alt={caseStudy.project_title} fill className="object-cover" />
        </div>

        {metricEntries.length > 0 && (
          <div className="mt-10 grid grid-cols-2 gap-6 rounded-2xl border border-border bg-card p-8 sm:grid-cols-4">
            {metricEntries.map(([key, value]) => (
              <div key={key}>
                <p className="font-display text-2xl font-semibold">{String(value)}</p>
                <p className="mt-1 text-xs uppercase tracking-wide text-muted">
                  {METRIC_LABELS[key] ?? key}
                </p>
              </div>
            ))}
          </div>
        )}

        <div className="mt-14 grid gap-10 pb-24 lg:grid-cols-2">
          <Section title="Challenge" body={caseStudy.challenge} />
          <Section title="Strategy" body={caseStudy.strategy} />
          <Section title="Execution" body={caseStudy.execution} />
          <Section title="Results" body={caseStudy.results} />
          {caseStudy.key_learnings && (
            <div className="lg:col-span-2">
              <Section title="Key Learnings" body={caseStudy.key_learnings} />
            </div>
          )}
        </div>
      </div>
    </article>
  );
}

function Section({ title, body }: { title: string; body: string }) {
  if (!body) return null;
  return (
    <div>
      <h2 className="font-display text-xl font-semibold">{title}</h2>
      <p className="mt-3 leading-relaxed text-muted">{body}</p>
    </div>
  );
}

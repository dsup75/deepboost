"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { TextField, TextAreaField, ToggleField, SelectField } from "@/components/admin/FormField";
import type { CreativeWork, CreativeWorkCategory } from "@/types";

const CATEGORIES: CreativeWorkCategory[] = ["Social Media", "Ads", "Posters", "Branding", "Campaigns"];

const EMPTY: Omit<CreativeWork, "id" | "created_at" | "updated_at"> = {
  title: "",
  slug: "",
  category: "Social Media",
  description: "",
  image_url: "",
  additional_image_urls: [],
  tags: [],
  featured: false,
  published: false,
};

function slugify(input: string) {
  return input.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export default function CreativeWorkEditPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const isNew = params.id === "new";

  const [form, setForm] = useState(EMPTY);
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (isNew) return;
    async function load() {
      const supabase = createClient();
      const { data } = await supabase.from("creative_works").select("*").eq("id", params.id).single();
      if (data) setForm(data as unknown as CreativeWork);
      setLoading(false);
    }
    load();
  }, [isNew, params.id]);

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSave(publish?: boolean) {
    setSaving(true);
    const supabase = createClient();
    const payload = { ...form, slug: form.slug || slugify(form.title), published: publish ?? form.published };

    if (isNew) {
      const { data, error } = await supabase.from("creative_works").insert(payload).select().single();
      setSaving(false);
      if (!error && data) router.push(`/admin/creative-works/${data.id}`);
    } else {
      await supabase.from("creative_works").update(payload).eq("id", params.id);
      setSaving(false);
      setForm(payload);
    }
  }

  async function handleDelete() {
    if (isNew || !confirm("Delete this creative work permanently?")) return;
    const supabase = createClient();
    await supabase.from("creative_works").delete().eq("id", params.id);
    router.push("/admin/creative-works");
  }

  if (loading) return <div className="p-10 text-muted">Loading...</div>;

  return (
    <div className="p-6 md:p-10">
      <Link href="/admin/creative-works" className="text-sm text-muted hover:text-text">← All Creative Works</Link>
      <h1 className="mt-4 font-display text-2xl font-semibold">{isNew ? "New Creative Work" : form.title}</h1>

      <div className="mt-6 grid gap-8 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-5">
          <TextField label="Title" value={form.title} onChange={(v) => set("title", v)} required />
          <TextField label="Slug" value={form.slug} onChange={(v) => set("slug", v)} placeholder="auto-generated if left blank" />
          <SelectField label="Category" value={form.category} onChange={(v) => set("category", v as CreativeWorkCategory)} options={CATEGORIES} />
          <TextAreaField label="Description" value={form.description} onChange={(v) => set("description", v)} />
          <TextField label="Image URL" value={form.image_url} onChange={(v) => set("image_url", v)} />
        </div>

        <div className="space-y-5">
          <div className="card-surface space-y-4 p-5">
            <ToggleField label="Featured" value={form.featured} onChange={(v) => set("featured", v)} />
            <ToggleField label="Published" value={form.published} onChange={(v) => set("published", v)} />
          </div>
          <div className="flex flex-col gap-3">
            <button onClick={() => handleSave()} disabled={saving} className="btn-outline justify-center">
              {saving ? "Saving..." : "Save Draft"}
            </button>
            <button onClick={() => handleSave(true)} disabled={saving} className="btn-primary justify-center">
              {saving ? "Saving..." : form.published ? "Update" : "Publish"}
            </button>
            {!isNew && (
              <button onClick={handleDelete} className="rounded-full border border-red-500/30 px-6 py-3 text-sm font-semibold text-red-400 hover:bg-red-500/10">
                Delete
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

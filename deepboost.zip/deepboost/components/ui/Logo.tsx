export default function Logo({ className = "h-7 w-auto" }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 160 32"
      className={className}
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      role="img"
      aria-label="DeepBoost"
    >
      <defs>
        <linearGradient id="db-mark" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
          <stop stopColor="#7C3AED" />
          <stop offset="1" stopColor="#22D3EE" />
        </linearGradient>
      </defs>
      <path
        d="M4 4 L16 4 C23.7 4 30 10.3 30 18 C30 25.7 23.7 32 16 32 L4 32 Z M11 11 L11 25 L15.6 25 C19.9 25 23 21.6 23 18 C23 14.3 19.9 11 15.6 11 Z"
        transform="translate(0 -2) scale(0.85)"
        fill="url(#db-mark)"
      />
      <text
        x="36"
        y="22"
        fontFamily="var(--font-display), 'Space Grotesk', sans-serif"
        fontWeight="600"
        fontSize="18"
        letterSpacing="0.5"
        fill="#F5F5F7"
      >
        DEEPBOOST
      </text>
    </svg>
  );
}

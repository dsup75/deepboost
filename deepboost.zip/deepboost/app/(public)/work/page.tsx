import type { Metadata } from "next";
import { getCaseStudies } from "@/lib/data";
import CaseStudyGrid from "@/components/case-studies/CaseStudyGrid";

export const metadata: Metadata = {
  title: "Our Work",
  description: "Real campaigns and real performance data from DeepBoost client work.",
};

export default async function WorkPage() {
  const caseStudies = await getCaseStudies();

  return (
    <div className="pt-32">
      <div className="container-max px-6 pb-8 md:px-10 lg:px-16">
        <p className="eyebrow">Selected Work</p>
        <h1 className="mt-4 font-display text-5xl font-semibold tracking-tight">
          Real campaigns. Real performance data.
        </h1>
      </div>
      <CaseStudyGrid caseStudies={caseStudies} />
    </div>
  );
}

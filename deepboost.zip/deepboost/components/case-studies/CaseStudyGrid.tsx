"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import type { CaseStudy } from "@/types";

export default function CaseStudyGrid({ caseStudies }: { caseStudies: CaseStudy[] }) {
  if (caseStudies.length === 0) {
    return (
      <div className="container-max px-6 py-24 text-center text-muted md:px-10 lg:px-16">
        No case studies published yet. Add one from the admin dashboard.
      </div>
    );
  }

  return (
    <div className="container-max grid gap-6 px-6 pb-24 md:grid-cols-2 md:px-10 lg:px-16">
      {caseStudies.map((cs, i) => (
        <motion.div
          key={cs.id}
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: (i % 4) * 0.08 }}
        >
          <Link href={`/work/${cs.slug}`} className="group card-surface block overflow-hidden">
            <div className="relative aspect-[16/10] overflow-hidden">
              <Image
                src={cs.cover_image_url}
                alt={cs.project_title}
                fill
                className="object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-bg via-transparent to-transparent" />
            </div>
            <div className="p-6">
              <div className="flex items-center justify-between">
                <p className="eyebrow">{cs.industry}</p>
                <ArrowUpRight
                  size={18}
                  className="text-muted transition-all duration-300 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-cyan"
                />
              </div>
              <h3 className="mt-2 font-display text-xl font-semibold">{cs.project_title}</h3>
              <p className="mt-1 text-sm text-muted">{cs.client_name}</p>
            </div>
          </Link>
        </motion.div>
      ))}
    </div>
  );
}

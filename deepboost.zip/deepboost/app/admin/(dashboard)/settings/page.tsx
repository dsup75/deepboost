"use client";

import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { TextField, TextAreaField } from "@/components/admin/FormField";
import type { SiteSettings } from "@/types";

const EMPTY: SiteSettings = {
  id: "",
  company_name: "DeepBoost",
  contact_email: "deepboost1@gmail.com",
  cta_text: "Start a Project",
  footer_text: "© DeepBoost. All rights reserved.",
  social_links: {},
  seo_title: "DeepBoost — Creative & Digital Growth Agency",
  seo_description: "",
  updated_at: "",
};

export default function SettingsPage() {
  const [form, setForm] = useState<SiteSettings>(EMPTY);
  const [linksText, setLinksText] = useState("");
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    async function load() {
      const supabase = createClient();
      const { data } = await supabase.from("site_settings").select("*").limit(1).single();
      if (data) {
        const settings = data as unknown as SiteSettings;
        setForm(settings);
        setLinksText(
          Object.entries(settings.social_links || {})
            .map(([k, v]) => `${k}: ${v}`)
            .join("\n")
        );
      }
      setLoading(false);
    }
    load();
  }, []);

  function set<K extends keyof SiteSettings>(key: K, value: SiteSettings[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  function parseLinks(text: string): Record<string, string> {
    const out: Record<string, string> = {};
    text.split("\n").forEach((line) => {
      const [k, ...rest] = line.split(":");
      if (k && rest.length) out[k.trim()] = rest.join(":").trim();
    });
    return out;
  }

  async function handleSave() {
    setSaving(true);
    const supabase = createClient();
    const payload = { ...form, social_links: parseLinks(linksText) };
    // sanitize: strip any HTML tags from freeform text fields
    const stripHtml = (s: string) => s.replace(/<[^>]*>/g, "");
    payload.footer_text = stripHtml(payload.footer_text);
    payload.seo_description = stripHtml(payload.seo_description);

    await supabase.from("site_settings").update(payload).eq("id", form.id);
    setSaving(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  if (loading) return <div className="p-10 text-muted">Loading...</div>;

  return (
    <div className="p-6 md:p-10">
      <h1 className="font-display text-2xl font-semibold">Site Settings</h1>
      <p className="mt-1 text-sm text-muted">Global content shown across the public site.</p>

      <div className="mt-6 max-w-xl space-y-5">
        <TextField label="Company Name" value={form.company_name} onChange={(v) => set("company_name", v)} />
        <TextField label="Contact Email" value={form.contact_email} onChange={(v) => set("contact_email", v)} />
        <TextField label="CTA Text" value={form.cta_text} onChange={(v) => set("cta_text", v)} />
        <TextAreaField label="Footer Text" value={form.footer_text} onChange={(v) => set("footer_text", v)} rows={2} />
        <TextAreaField
          label="Social Links (one per line — label: url)"
          value={linksText}
          onChange={setLinksText}
          rows={3}
        />
        <TextField label="SEO Title" value={form.seo_title} onChange={(v) => set("seo_title", v)} />
        <TextAreaField label="SEO Description" value={form.seo_description} onChange={(v) => set("seo_description", v)} rows={3} />

        <button onClick={handleSave} disabled={saving} className="btn-primary">
          {saving ? "Saving..." : saved ? "Saved ✓" : "Save Settings"}
        </button>
      </div>
    </div>
  );
}

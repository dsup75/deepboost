/**
 * Centralized asset registry.
 *
 * TEMPORARY placeholder images from Unsplash are used for development.
 * Replace any URL below with your own CDN/Supabase Storage URL later —
 * this is the ONLY file that should contain hardcoded image URLs.
 * Never scatter image URLs directly inside components.
 */

export const assets = {
  brand: {
    logo: "/brand/logo.svg",
    logoMark: "/brand/logo-mark.svg",
    favicon: "/brand/favicon.svg",
  },

  hero: {
    backgroundGlow:
      "https://images.unsplash.com/photo-1451187580459-43490279c0fa?q=80&w=2400&auto=format&fit=crop",
  },

  services: {
    performance:
      "https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=1600&auto=format&fit=crop",
    creative:
      "https://images.unsplash.com/photo-1626785774573-4b799315345d?q=80&w=1600&auto=format&fit=crop",
    social:
      "https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?q=80&w=1600&auto=format&fit=crop",
    growth:
      "https://images.unsplash.com/photo-1553877522-43269d4ea984?q=80&w=1600&auto=format&fit=crop",
    branding:
      "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=1600&auto=format&fit=crop",
  },

  caseStudies: {
    placeholder:
      "https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=1600&auto=format&fit=crop",
  },

  creativeWorks: {
    placeholder:
      "https://images.unsplash.com/photo-1633613286848-e6f43bbafb8d?q=80&w=1600&auto=format&fit=crop",
  },

  about: {
    image:
      "https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=1600&auto=format&fit=crop",
  },
};

"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Plus, Trash2, Star, Eye, EyeOff } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import type { CreativeWork } from "@/types";

export default function CreativeWorksListPage() {
  const [items, setItems] = useState<CreativeWork[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const supabase = createClient();
    const { data } = await supabase.from("creative_works").select("*").order("created_at", { ascending: false });
    setItems((data as unknown as CreativeWork[]) ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function toggle(id: string, field: "published" | "featured", value: boolean) {
    const supabase = createClient();
    await supabase.from("creative_works").update({ [field]: value }).eq("id", id);
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, [field]: value } : i)));
  }

  async function remove(id: string) {
    if (!confirm("Delete this creative work permanently?")) return;
    const supabase = createClient();
    await supabase.from("creative_works").delete().eq("id", id);
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  return (
    <div className="p-6 md:p-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold">Creative Works</h1>
          <p className="mt-1 text-sm text-muted">Portfolio pieces shown in the Creative Works grid.</p>
        </div>
        <Link href="/admin/creative-works/new" className="btn-primary">
          <Plus size={16} /> New Work
        </Link>
      </div>

      <div className="mt-6 overflow-x-auto rounded-xl border border-border">
        <table className="w-full text-left text-sm">
          <thead className="bg-bg-secondary text-muted">
            <tr>
              <th className="px-4 py-3 font-medium">Title</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium" />
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={4} className="px-4 py-8 text-center text-muted">Loading...</td></tr>
            ) : items.length === 0 ? (
              <tr><td colSpan={4} className="px-4 py-8 text-center text-muted">No creative works yet.</td></tr>
            ) : (
              items.map((w) => (
                <tr key={w.id} className="border-t border-border">
                  <td className="px-4 py-3">
                    <Link href={`/admin/creative-works/${w.id}`} className="hover:text-cyan">{w.title}</Link>
                  </td>
                  <td className="px-4 py-3">{w.category}</td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-xs ${w.published ? "bg-cyan/15 text-cyan" : "bg-white/10 text-muted"}`}>
                      {w.published ? "Published" : "Draft"}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-3 text-muted">
                      <button onClick={() => toggle(w.id, "featured", !w.featured)} className={w.featured ? "text-violet" : ""}><Star size={15} /></button>
                      <button onClick={() => toggle(w.id, "published", !w.published)}>{w.published ? <Eye size={15} /> : <EyeOff size={15} />}</button>
                      <button onClick={() => remove(w.id)} className="hover:text-red-400"><Trash2 size={15} /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

import type { Metadata } from "next";
import { Inter, Space_Grotesk } from "next/font/google";
import "./globals.css";

const sans = Inter({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
});

const display = Space_Grotesk({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL || "https://deepboost.com";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "DeepBoost — Creative & Digital Growth Agency",
    template: "%s | DeepBoost",
  },
  description:
    "DeepBoost is a global creative and digital growth agency specializing in performance marketing, creative production, social media management and digital growth.",
  keywords: [
    "performance marketing agency",
    "meta ads agency",
    "creative production agency",
    "social media management",
    "digital growth agency",
  ],
  openGraph: {
    title: "DeepBoost — Creative & Digital Growth Agency",
    description:
      "Creative systems and performance strategies built to turn attention into measurable growth.",
    url: siteUrl,
    siteName: "DeepBoost",
    type: "website",
    images: [{ url: "/brand/og-image.jpg", width: 1200, height: 630, alt: "DeepBoost" }],
  },
  twitter: {
    card: "summary_large_image",
    title: "DeepBoost — Creative & Digital Growth Agency",
    description:
      "Creative systems and performance strategies built to turn attention into measurable growth.",
    images: ["/brand/og-image.jpg"],
  },
  icons: {
    icon: "/brand/favicon.svg",
  },
  manifest: "/manifest.json",
};

const orgSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "DeepBoost",
  url: siteUrl,
  logo: `${siteUrl}/brand/logo.svg`,
  description:
    "DeepBoost is a global creative and digital growth agency specializing in performance marketing, creative production, social media management and digital growth.",
  email: "deepboost1@gmail.com",
  sameAs: [],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={`${sans.variable} ${display.variable}`}>
      <body>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(orgSchema) }}
        />
        {children}
      </body>
    </html>
  );
}

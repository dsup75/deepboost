"use client";

import { motion } from "framer-motion";

const STEPS = [
  { n: "01", title: "Discover", desc: "Understand the brand, audience and growth goals." },
  { n: "02", title: "Strategize", desc: "Build a channel and creative strategy around the data." },
  { n: "03", title: "Create", desc: "Produce creative assets built to perform, not just look good." },
  { n: "04", title: "Launch", desc: "Deploy campaigns across the right platforms and audiences." },
  { n: "05", title: "Optimize", desc: "Test, refine and reallocate spend toward what's working." },
  { n: "06", title: "Scale", desc: "Expand what performs into a repeatable growth engine." },
];

export default function Process() {
  return (
    <section id="process" className="section-pad border-t border-border bg-bg-secondary">
      <div className="container-max">
        <div className="max-w-xl">
          <p className="eyebrow">Process</p>
          <h2 className="mt-4 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
            A clear path from idea to growth.
          </h2>
        </div>

        <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {STEPS.map((s, i) => (
            <motion.div
              key={s.n}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.07 }}
              className="card-surface p-7"
            >
              <span className="font-display text-2xl text-muted">{s.n}</span>
              <h3 className="mt-4 font-display text-lg font-semibold">{s.title}</h3>
              <p className="mt-2 text-sm text-muted">{s.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

import { createClient } from "@/lib/supabase/server";
import { FileText, Image as ImageIcon, Layers, Mail } from "lucide-react";

const SUPABASE_CONFIGURED =
  !!process.env.NEXT_PUBLIC_SUPABASE_URL && !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

async function getCounts() {
  if (!SUPABASE_CONFIGURED) {
    return { caseStudies: 0, creativeWorks: 0, services: 0, leads: 0 };
  }
  const supabase = createClient();
  const [caseStudies, creativeWorks, services, leads] = await Promise.all([
    supabase.from("case_studies").select("id", { count: "exact", head: true }),
    supabase.from("creative_works").select("id", { count: "exact", head: true }),
    supabase.from("services").select("id", { count: "exact", head: true }),
    supabase.from("contact_submissions").select("id", { count: "exact", head: true }),
  ]);
  return {
    caseStudies: caseStudies.count ?? 0,
    creativeWorks: creativeWorks.count ?? 0,
    services: services.count ?? 0,
    leads: leads.count ?? 0,
  };
}

async function getRecentInquiries() {
  if (!SUPABASE_CONFIGURED) return [];
  const supabase = createClient();
  const { data } = await supabase
    .from("contact_submissions")
    .select("*")
    .order("created_at", { ascending: false })
    .limit(5);
  return data ?? [];
}

export default async function DashboardPage() {
  const counts = await getCounts();
  const recent = await getRecentInquiries();

  const cards = [
    { label: "Case Studies", value: counts.caseStudies, icon: FileText },
    { label: "Creative Works", value: counts.creativeWorks, icon: ImageIcon },
    { label: "Services", value: counts.services, icon: Layers },
    { label: "Total Leads", value: counts.leads, icon: Mail },
  ];

  return (
    <div className="p-6 md:p-10">
      <h1 className="font-display text-2xl font-semibold">Dashboard</h1>
      <p className="mt-1 text-sm text-muted">Overview of DeepBoost content and inquiries.</p>

      {!SUPABASE_CONFIGURED && (
        <div className="mt-6 rounded-xl border border-yellow-500/30 bg-yellow-500/10 p-4 text-sm text-yellow-200">
          Supabase environment variables aren&apos;t set yet. Connect a project and run
          supabase/schema.sql to see live data here.
        </div>
      )}

      <div className="mt-6 grid grid-cols-2 gap-4 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="card-surface p-6">
            <c.icon size={18} className="text-cyan" />
            <p className="mt-4 font-display text-3xl font-semibold">{c.value}</p>
            <p className="mt-1 text-sm text-muted">{c.label}</p>
          </div>
        ))}
      </div>

      <div className="mt-10">
        <h2 className="font-display text-lg font-semibold">Recent Inquiries</h2>
        <div className="mt-4 overflow-x-auto rounded-xl border border-border">
          <table className="w-full text-left text-sm">
            <thead className="bg-bg-secondary text-muted">
              <tr>
                <th className="px-4 py-3 font-medium">Name</th>
                <th className="px-4 py-3 font-medium">Company</th>
                <th className="px-4 py-3 font-medium">Service</th>
                <th className="px-4 py-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {recent.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-4 py-6 text-center text-muted">
                    No inquiries yet.
                  </td>
                </tr>
              ) : (
                recent.map((r: any) => (
                  <tr key={r.id} className="border-t border-border">
                    <td className="px-4 py-3">{r.name}</td>
                    <td className="px-4 py-3">{r.company}</td>
                    <td className="px-4 py-3">{r.service}</td>
                    <td className="px-4 py-3">{r.status}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

"use client";

import { useEffect, useState } from "react";
import { Plus, Trash2, Save } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import type { Metric } from "@/types";

export default function MetricsPage() {
  const [items, setItems] = useState<Metric[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState<string | null>(null);

  async function load() {
    setLoading(true);
    const supabase = createClient();
    const { data } = await supabase.from("metrics").select("*").order("order");
    setItems((data as unknown as Metric[]) ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  function update(id: string, field: "label" | "value", val: string) {
    setItems((prev) => prev.map((m) => (m.id === id ? { ...m, [field]: val } : m)));
  }

  async function save(metric: Metric) {
    setSavingId(metric.id);
    const supabase = createClient();
    await supabase.from("metrics").update({ label: metric.label, value: metric.value }).eq("id", metric.id);
    setSavingId(null);
  }

  async function remove(id: string) {
    if (!confirm("Delete this metric?")) return;
    const supabase = createClient();
    await supabase.from("metrics").delete().eq("id", id);
    setItems((prev) => prev.filter((m) => m.id !== id));
  }

  async function addMetric() {
    const supabase = createClient();
    const key = `metric_${Date.now()}`;
    const { data } = await supabase
      .from("metrics")
      .insert({ key, label: "NEW METRIC", value: "0", order: items.length + 1 })
      .select()
      .single();
    if (data) setItems((prev) => [...prev, data as unknown as Metric]);
  }

  return (
    <div className="p-6 md:p-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold">Metrics</h1>
          <p className="mt-1 text-sm text-muted">
            Homepage animated counters. Use only verified campaign data — these update the
            live site instantly.
          </p>
        </div>
        <button onClick={addMetric} className="btn-primary"><Plus size={16} /> Add Metric</button>
      </div>

      {loading ? (
        <p className="mt-8 text-muted">Loading...</p>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2">
          {items.map((m) => (
            <div key={m.id} className="card-surface space-y-3 p-5">
              <div>
                <label className="mb-1 block text-xs text-muted">Value</label>
                <input
                  value={m.value}
                  onChange={(e) => update(m.id, "value", e.target.value)}
                  className="w-full rounded-lg border border-border bg-bg px-3 py-2 text-lg font-display outline-none focus:border-violet"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs text-muted">Label</label>
                <input
                  value={m.label}
                  onChange={(e) => update(m.id, "label", e.target.value)}
                  className="w-full rounded-lg border border-border bg-bg px-3 py-2 text-sm outline-none focus:border-violet"
                />
              </div>
              <div className="flex items-center gap-3 pt-1">
                <button
                  onClick={() => save(m)}
                  disabled={savingId === m.id}
                  className="flex items-center gap-1 text-sm text-cyan hover:opacity-80"
                >
                  <Save size={14} /> {savingId === m.id ? "Saving..." : "Save"}
                </button>
                <button onClick={() => remove(m.id)} className="flex items-center gap-1 text-sm text-muted hover:text-red-400">
                  <Trash2 size={14} /> Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

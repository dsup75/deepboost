"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import {
  LayoutDashboard,
  FileText,
  Image as ImageIcon,
  Layers,
  BarChart3,
  Folder,
  Settings,
  LogOut,
  Menu,
  X,
  Mail,
} from "lucide-react";
import Logo from "@/components/ui/Logo";
import { createClient } from "@/lib/supabase/client";

const NAV = [
  { label: "Dashboard", href: "/admin/dashboard", icon: LayoutDashboard },
  { label: "Case Studies", href: "/admin/case-studies", icon: FileText },
  { label: "Creative Works", href: "/admin/creative-works", icon: ImageIcon },
  { label: "Services", href: "/admin/services", icon: Layers },
  { label: "Metrics", href: "/admin/metrics", icon: BarChart3 },
  { label: "Media", href: "/admin/media", icon: Folder },
  { label: "Inquiries", href: "/admin/inquiries", icon: Mail },
  { label: "Settings", href: "/admin/settings", icon: Settings },
];

function NavLinks({ onNavigate }: { onNavigate?: () => void }) {
  const pathname = usePathname();
  return (
    <nav className="flex flex-1 flex-col gap-1">
      {NAV.map((item) => {
        const active = pathname?.startsWith(item.href);
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={`flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm transition-colors ${
              active ? "bg-white/10 text-text" : "text-muted hover:bg-white/5 hover:text-text"
            }`}
          >
            <item.icon size={17} />
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}

export default function Sidebar() {
  const [open, setOpen] = useState(false);
  const router = useRouter();

  async function handleLogout() {
    const supabase = createClient();
    await supabase.auth.signOut();
    router.push("/admin/login");
    router.refresh();
  }

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden w-60 flex-col border-r border-border bg-bg-secondary p-4 md:flex">
        <div className="px-2 py-3">
          <Logo className="h-6 w-auto" />
        </div>
        <NavLinks />
        <button
          onClick={handleLogout}
          className="mt-4 flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-muted hover:bg-white/5 hover:text-text"
        >
          <LogOut size={17} /> Logout
        </button>
      </aside>

      {/* Mobile top bar + drawer */}
      <div className="flex items-center justify-between border-b border-border p-4 md:hidden">
        <Logo className="h-6 w-auto" />
        <button onClick={() => setOpen(true)} aria-label="Open menu">
          <Menu size={22} />
        </button>
      </div>

      {open && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div className="flex w-72 flex-col bg-bg-secondary p-4">
            <div className="flex items-center justify-between px-2 py-3">
              <Logo className="h-6 w-auto" />
              <button onClick={() => setOpen(false)} aria-label="Close menu">
                <X size={22} />
              </button>
            </div>
            <NavLinks onNavigate={() => setOpen(false)} />
            <button
              onClick={handleLogout}
              className="mt-4 flex items-center gap-3 rounded-lg px-3 py-2.5 text-sm text-muted hover:bg-white/5 hover:text-text"
            >
              <LogOut size={17} /> Logout
            </button>
          </div>
          <div className="flex-1 bg-black/60" onClick={() => setOpen(false)} />
        </div>
      )}
    </>
  );
}

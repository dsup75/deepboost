"use client";

import { useEffect, useState, FormEvent } from "react";
import Image from "next/image";
import { Plus, Trash2, X } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import type { MediaItem } from "@/types";

export default function MediaPage() {
  const [items, setItems] = useState<MediaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ url: "", title: "", alt_text: "", category: "general" });
  const [saving, setSaving] = useState(false);

  async function load() {
    setLoading(true);
    const supabase = createClient();
    const { data } = await supabase.from("media").select("*").order("created_at", { ascending: false });
    setItems((data as unknown as MediaItem[]) ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function handleAdd(e: FormEvent) {
    e.preventDefault();
    setSaving(true);
    const supabase = createClient();
    const { data, error } = await supabase.from("media").insert(form).select().single();
    setSaving(false);
    if (!error && data) {
      setItems((prev) => [data as unknown as MediaItem, ...prev]);
      setForm({ url: "", title: "", alt_text: "", category: "general" });
      setShowForm(false);
    }
  }

  async function remove(id: string) {
    if (!confirm("Remove this media item?")) return;
    const supabase = createClient();
    await supabase.from("media").delete().eq("id", id);
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  return (
    <div className="p-6 md:p-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold">Media Library</h1>
          <p className="mt-1 text-sm text-muted">
            External image URLs used across the site. Ready for Supabase Storage or Cloudinary later.
          </p>
        </div>
        <button onClick={() => setShowForm((s) => !s)} className="btn-primary">
          {showForm ? <X size={16} /> : <Plus size={16} />} {showForm ? "Cancel" : "Add Image"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleAdd} className="card-surface mt-6 grid gap-4 p-6 sm:grid-cols-2">
          <input
            required
            placeholder="Image URL"
            value={form.url}
            onChange={(e) => setForm((f) => ({ ...f, url: e.target.value }))}
            className="rounded-lg border border-border bg-bg px-3 py-2 text-sm outline-none focus:border-violet sm:col-span-2"
          />
          <input
            placeholder="Title"
            value={form.title}
            onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))}
            className="rounded-lg border border-border bg-bg px-3 py-2 text-sm outline-none focus:border-violet"
          />
          <input
            placeholder="Alt text"
            value={form.alt_text}
            onChange={(e) => setForm((f) => ({ ...f, alt_text: e.target.value }))}
            className="rounded-lg border border-border bg-bg px-3 py-2 text-sm outline-none focus:border-violet"
          />
          <input
            placeholder="Category"
            value={form.category}
            onChange={(e) => setForm((f) => ({ ...f, category: e.target.value }))}
            className="rounded-lg border border-border bg-bg px-3 py-2 text-sm outline-none focus:border-violet"
          />
          <button type="submit" disabled={saving} className="btn-primary justify-center sm:col-span-2">
            {saving ? "Saving..." : "Save to Library"}
          </button>
        </form>
      )}

      {loading ? (
        <p className="mt-8 text-muted">Loading...</p>
      ) : items.length === 0 ? (
        <p className="mt-8 text-muted">No media items yet.</p>
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {items.map((item) => (
            <div key={item.id} className="group relative overflow-hidden rounded-xl border border-border">
              <div className="relative aspect-square">
                <Image src={item.url} alt={item.alt_text || item.title} fill className="object-cover" unoptimized />
              </div>
              <div className="p-2">
                <p className="truncate text-xs text-muted">{item.title || "Untitled"}</p>
              </div>
              <button
                onClick={() => remove(item.id)}
                className="absolute right-2 top-2 rounded-full bg-bg/80 p-1.5 text-muted opacity-0 transition-opacity hover:text-red-400 group-hover:opacity-100"
                aria-label="Remove image"
              >
                <Trash2 size={13} />
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

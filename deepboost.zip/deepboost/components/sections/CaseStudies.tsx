"use client";

import Image from "next/image";
import Link from "next/link";
import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import type { CaseStudy } from "@/types";

export default function CaseStudies({ caseStudies }: { caseStudies: CaseStudy[] }) {
  if (caseStudies.length === 0) return null;

  return (
    <section className="section-pad">
      <div className="container-max">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <div className="max-w-xl">
            <p className="eyebrow">Selected Work</p>
            <h2 className="mt-4 font-display text-4xl font-semibold tracking-tight sm:text-5xl">
              Real campaigns. Real performance data.
            </h2>
          </div>
          <Link href="/work" className="btn-outline">
            View All Work <span aria-hidden>→</span>
          </Link>
        </div>

        <div className="mt-14 grid gap-6 md:grid-cols-2">
          {caseStudies.slice(0, 4).map((cs, i) => (
            <motion.div
              key={cs.id}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
            >
              <Link
                href={`/work/${cs.slug}`}
                className="group card-surface block overflow-hidden"
              >
                <div className="relative aspect-[16/10] overflow-hidden">
                  <Image
                    src={cs.cover_image_url}
                    alt={cs.project_title}
                    fill
                    className="object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-bg via-transparent to-transparent" />
                </div>
                <div className="p-6">
                  <div className="flex items-center justify-between">
                    <p className="eyebrow">{cs.industry}</p>
                    <ArrowUpRight
                      size={18}
                      className="text-muted transition-all duration-300 group-hover:-translate-y-1 group-hover:translate-x-1 group-hover:text-cyan"
                    />
                  </div>
                  <h3 className="mt-2 font-display text-xl font-semibold">{cs.project_title}</h3>
                  <p className="mt-1 text-sm text-muted">{cs.client_name}</p>
                </div>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

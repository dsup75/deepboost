import Link from "next/link";
import Logo from "@/components/ui/Logo";

const LINKS = {
  Company: [
    { label: "About", href: "/about" },
    { label: "Work", href: "/work" },
    { label: "Contact", href: "/contact" },
  ],
  Services: [
    { label: "Performance Marketing", href: "/services#performance-marketing" },
    { label: "Creative Maker", href: "/services#creative-maker" },
    { label: "Social Media Management", href: "/services#social-media-management" },
    { label: "Digital Growth", href: "/services#digital-growth" },
  ],
};

export default function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="container-max px-6 py-16 md:px-10 lg:px-16">
        <div className="flex flex-col justify-between gap-12 md:flex-row">
          <div className="max-w-sm">
            <Logo className="h-7 w-auto" />
            <p className="mt-4 text-sm text-muted">
              Creative systems and performance strategies built to turn attention into
              measurable growth.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-12 sm:gap-20">
            {Object.entries(LINKS).map(([heading, items]) => (
              <div key={heading}>
                <p className="text-xs uppercase tracking-[0.15em] text-muted">{heading}</p>
                <ul className="mt-4 space-y-3">
                  {items.map((item) => (
                    <li key={item.label}>
                      <Link href={item.href} className="text-sm text-text/80 hover:text-text">
                        {item.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-16 flex flex-col items-center justify-between gap-4 border-t border-border pt-8 text-sm text-muted sm:flex-row">
          <p>© {new Date().getFullYear()} DeepBoost. All rights reserved.</p>
          <a href="mailto:deepboost1@gmail.com" className="hover:text-text">
            deepboost1@gmail.com
          </a>
        </div>
      </div>
    </footer>
  );
}

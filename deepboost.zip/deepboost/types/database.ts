/**
 * This is a hand-written placeholder for the Supabase generated types.
 *
 * Once you've created a Supabase project and run `supabase/schema.sql`,
 * regenerate this file for full type safety with:
 *
 *   npx supabase gen types typescript --project-id YOUR_PROJECT_ID --schema public > types/database.ts
 */

export type Json = string | number | boolean | null | { [key: string]: Json } | Json[];

export interface Database {
  public: {
    Tables: {
      [key: string]: {
        Row: Record<string, unknown>;
        Insert: Record<string, unknown>;
        Update: Record<string, unknown>;
      };
    };
    Views: Record<string, never>;
    Functions: Record<string, never>;
    Enums: Record<string, never>;
  };
}

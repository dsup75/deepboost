"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Plus, Trash2, Star, Eye, EyeOff } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import type { CaseStudy } from "@/types";

export default function CaseStudiesListPage() {
  const [items, setItems] = useState<CaseStudy[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const supabase = createClient();
    const { data } = await supabase
      .from("case_studies")
      .select("*")
      .order("created_at", { ascending: false });
    setItems((data as unknown as CaseStudy[]) ?? []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function toggle(id: string, field: "published" | "featured", value: boolean) {
    const supabase = createClient();
    await supabase.from("case_studies").update({ [field]: value }).eq("id", id);
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, [field]: value } : i)));
  }

  async function remove(id: string) {
    if (!confirm("Delete this case study permanently?")) return;
    const supabase = createClient();
    await supabase.from("case_studies").delete().eq("id", id);
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  async function duplicate(item: CaseStudy) {
    const supabase = createClient();
    const { id, created_at, updated_at, ...rest } = item;
    await supabase.from("case_studies").insert({
      ...rest,
      project_title: `${item.project_title} (Copy)`,
      slug: `${item.slug}-copy-${Date.now()}`,
      published: false,
    });
    load();
  }

  return (
    <div className="p-6 md:p-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold">Case Studies</h1>
          <p className="mt-1 text-sm text-muted">Client campaign results shown on /work.</p>
        </div>
        <Link href="/admin/case-studies/new" className="btn-primary">
          <Plus size={16} /> New Case Study
        </Link>
      </div>

      <div className="mt-6 overflow-x-auto rounded-xl border border-border">
        <table className="w-full text-left text-sm">
          <thead className="bg-bg-secondary text-muted">
            <tr>
              <th className="px-4 py-3 font-medium">Project</th>
              <th className="px-4 py-3 font-medium">Client</th>
              <th className="px-4 py-3 font-medium">Industry</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium" />
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-muted">Loading...</td>
              </tr>
            ) : items.length === 0 ? (
              <tr>
                <td colSpan={5} className="px-4 py-8 text-center text-muted">No case studies yet.</td>
              </tr>
            ) : (
              items.map((cs) => (
                <tr key={cs.id} className="border-t border-border">
                  <td className="px-4 py-3">
                    <Link href={`/admin/case-studies/${cs.id}`} className="hover:text-cyan">
                      {cs.project_title}
                    </Link>
                  </td>
                  <td className="px-4 py-3">{cs.client_name}</td>
                  <td className="px-4 py-3">{cs.industry}</td>
                  <td className="px-4 py-3">
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs ${
                        cs.published ? "bg-cyan/15 text-cyan" : "bg-white/10 text-muted"
                      }`}
                    >
                      {cs.published ? "Published" : "Draft"}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-3 text-muted">
                      <button
                        onClick={() => toggle(cs.id, "featured", !cs.featured)}
                        aria-label="Toggle featured"
                        className={cs.featured ? "text-violet" : ""}
                      >
                        <Star size={15} />
                      </button>
                      <button
                        onClick={() => toggle(cs.id, "published", !cs.published)}
                        aria-label="Toggle published"
                      >
                        {cs.published ? <Eye size={15} /> : <EyeOff size={15} />}
                      </button>
                      <button onClick={() => duplicate(cs)} className="text-xs hover:text-text">
                        Duplicate
                      </button>
                      <button onClick={() => remove(cs.id)} className="hover:text-red-400">
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

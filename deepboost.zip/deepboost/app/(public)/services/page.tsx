import type { Metadata } from "next";
import { getServices } from "@/lib/data";
import Services from "@/components/sections/Services";
import CTA from "@/components/sections/CTA";

export const metadata: Metadata = {
  title: "Services",
  description:
    "Performance marketing, creative production, social media management, digital growth, and brand & content services from DeepBoost.",
};

export default async function ServicesPage() {
  const services = await getServices();

  return (
    <div className="pt-20">
      <div className="section-pad pb-0">
        <div className="container-max">
          <p className="eyebrow">Services</p>
          <h1 className="mt-4 max-w-xl font-display text-5xl font-semibold leading-tight tracking-tight">
            Everything a growing brand needs, under one system.
          </h1>
        </div>
      </div>
      <Services services={services} />
      <CTA />
    </div>
  );
}

"use client";

import { motion } from "framer-motion";

const PILLARS = ["Creative + Performance", "Data + Design", "Strategy + Execution"];

export default function About() {
  return (
    <section className="section-pad">
      <div className="container-max grid gap-14 lg:grid-cols-2 lg:items-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <p className="eyebrow">About DeepBoost</p>
          <h2 className="mt-4 font-display text-4xl font-semibold leading-tight tracking-tight sm:text-5xl">
            Built for better growth.
          </h2>
          <p className="mt-5 max-w-md text-muted">
            DeepBoost brings creative production, performance marketing and digital
            strategy together to help ambitious brands grow with clarity and speed.
          </p>
        </motion.div>

        <div className="grid gap-4">
          {PILLARS.map((p, i) => (
            <motion.div
              key={p}
              initial={{ opacity: 0, x: 20 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
              className="card-surface flex items-center gap-4 px-6 py-5"
            >
              <span className="h-2 w-2 rounded-full bg-gradient-violet-cyan" />
              <span className="font-medium">{p}</span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

export type CaseStudyMetrics = {
  ad_spend?: string;
  impressions?: string;
  reach?: string;
  clicks?: string;
  ctr?: string;
  leads?: string;
  conversions?: string;
  cpl?: string;
};

export type CaseStudy = {
  id: string;
  client_name: string;
  industry: string;
  project_title: string;
  slug: string;
  challenge: string;
  strategy: string;
  execution: string;
  results: string;
  key_learnings: string;
  metrics: CaseStudyMetrics;
  cover_image_url: string;
  gallery_image_urls: string[];
  tags: string[];
  featured: boolean;
  published: boolean;
  created_at: string;
  updated_at: string;
};

export type CreativeWorkCategory =
  | "Social Media"
  | "Ads"
  | "Posters"
  | "Branding"
  | "Campaigns";

export type CreativeWork = {
  id: string;
  title: string;
  slug: string;
  category: CreativeWorkCategory;
  description: string;
  image_url: string;
  additional_image_urls: string[];
  tags: string[];
  featured: boolean;
  published: boolean;
  created_at: string;
  updated_at: string;
};

export type Service = {
  id: string;
  name: string;
  slug: string;
  description: string;
  features: string[];
  icon: string;
  visual_3d: string | null;
  order: number;
  featured: boolean;
  published: boolean;
  created_at: string;
  updated_at: string;
};

export type Metric = {
  id: string;
  key: string;
  label: string;
  value: string;
  order: number;
  updated_at: string;
};

export type MediaItem = {
  id: string;
  url: string;
  title: string;
  alt_text: string;
  category: string;
  created_at: string;
};

export type SiteSettings = {
  id: string;
  company_name: string;
  contact_email: string;
  cta_text: string;
  footer_text: string;
  social_links: Record<string, string>;
  seo_title: string;
  seo_description: string;
  updated_at: string;
};

export type InquiryStatus = "New" | "Contacted" | "Qualified" | "Converted" | "Closed";

export type ContactSubmission = {
  id: string;
  name: string;
  company: string;
  email: string;
  phone: string | null;
  country: string | null;
  service: string;
  budget: string | null;
  project_details: string;
  status: InquiryStatus;
  created_at: string;
};

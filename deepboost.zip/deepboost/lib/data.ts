import { createClient } from "@/lib/supabase/server";
import { assets } from "@/lib/assets";
import type { CaseStudy, CreativeWork, Metric, Service } from "@/types";

const SUPABASE_CONFIGURED =
  !!process.env.NEXT_PUBLIC_SUPABASE_URL && !!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

// ---------------------------------------------------------------------
// Fallback content shown only until Supabase is connected & seeded.
// Once env vars are set and supabase/schema.sql has been run, every
// function below reads live data instead.
// ---------------------------------------------------------------------

const FALLBACK_METRICS: Metric[] = [
  { id: "1", key: "ad_spend", label: "AD SPEND MANAGED", value: "₹3.1L+", order: 1, updated_at: "" },
  { id: "2", key: "leads", label: "LEADS GENERATED", value: "1,254+", order: 2, updated_at: "" },
  { id: "3", key: "reach", label: "REACH", value: "1.78M+", order: 3, updated_at: "" },
  { id: "4", key: "campaigns", label: "CAMPAIGNS", value: "6+", order: 4, updated_at: "" },
];

const FALLBACK_SERVICES: Service[] = [
  {
    id: "1",
    name: "Performance Marketing",
    slug: "performance-marketing",
    description: "Meta Ads strategy, targeting and optimization built around measurable growth.",
    features: ["Meta Ads", "Lead Generation", "Campaign Strategy", "Audience Targeting", "Creative Testing", "Optimization", "Conversion Tracking"],
    icon: "target",
    visual_3d: null,
    order: 1,
    featured: true,
    published: true,
    created_at: "",
    updated_at: "",
  },
  {
    id: "2",
    name: "Creative Maker",
    slug: "creative-maker",
    description: "Ad and social creatives designed to stop the scroll and convert attention.",
    features: ["Social Media Creatives", "Ad Creatives", "Posters", "Campaign Designs", "Promotional Graphics", "Brand Creatives", "AI-assisted Creative Production"],
    icon: "palette",
    visual_3d: null,
    order: 2,
    featured: true,
    published: true,
    created_at: "",
    updated_at: "",
  },
  {
    id: "3",
    name: "Social Media Management",
    slug: "social-media-management",
    description: "Full-funnel social operations from strategy through analytics.",
    features: ["Instagram Management", "Facebook Management", "Content Strategy", "Content Calendar", "Publishing & Scheduling", "Community Engagement", "Analytics & Reporting"],
    icon: "share2",
    visual_3d: null,
    order: 3,
    featured: true,
    published: true,
    created_at: "",
    updated_at: "",
  },
  {
    id: "4",
    name: "Digital Growth",
    slug: "digital-growth",
    description: "Funnels and reporting systems built to compound performance over time.",
    features: ["Growth Strategy", "Marketing Funnels", "Conversion Optimization", "Analytics", "Performance Reporting", "Digital Campaigns"],
    icon: "trending-up",
    visual_3d: null,
    order: 4,
    featured: true,
    published: true,
    created_at: "",
    updated_at: "",
  },
  {
    id: "5",
    name: "Brand & Content",
    slug: "brand-content",
    description: "Visual identity and content systems that keep every channel consistent.",
    features: ["Visual Identity", "Campaign Concepts", "Content Systems", "Brand Communication", "Creative Direction"],
    icon: "layers",
    visual_3d: null,
    order: 5,
    featured: true,
    published: true,
    created_at: "",
    updated_at: "",
  },
];

const FALLBACK_CASE_STUDY_NAMES = [
  "Solar Ji",
  "Sahu Motors",
  "GG Organic",
  "Kalpana Solar Traders",
  "GDFL",
  "Cult Canvas",
];

const FALLBACK_CASE_STUDIES: CaseStudy[] = FALLBACK_CASE_STUDY_NAMES.map((name, i) => ({
  id: String(i + 1),
  client_name: name,
  industry: "—",
  project_title: name,
  slug: name.toLowerCase().replace(/\s+/g, "-"),
  challenge: "Add this case study's challenge in the admin dashboard.",
  strategy: "Add this case study's strategy in the admin dashboard.",
  execution: "Add this case study's execution in the admin dashboard.",
  results: "Add this case study's results in the admin dashboard.",
  key_learnings: "Add key learnings in the admin dashboard.",
  metrics: {},
  cover_image_url: assets.caseStudies.placeholder,
  gallery_image_urls: [],
  tags: [],
  featured: i < 4,
  published: true,
  created_at: "",
  updated_at: "",
}));

// ---------------------------------------------------------------------

export async function getMetrics(): Promise<Metric[]> {
  if (!SUPABASE_CONFIGURED) return FALLBACK_METRICS;
  const supabase = createClient();
  const { data, error } = await supabase.from("metrics").select("*").order("order");
  if (error || !data || data.length === 0) return FALLBACK_METRICS;
  return data as unknown as Metric[];
}

export async function getServices(): Promise<Service[]> {
  if (!SUPABASE_CONFIGURED) return FALLBACK_SERVICES;
  const supabase = createClient();
  const { data, error } = await supabase
    .from("services")
    .select("*")
    .eq("published", true)
    .order("order");
  if (error || !data || data.length === 0) return FALLBACK_SERVICES;
  return data as unknown as Service[];
}

export async function getCaseStudies(): Promise<CaseStudy[]> {
  if (!SUPABASE_CONFIGURED) return FALLBACK_CASE_STUDIES;
  const supabase = createClient();
  const { data, error } = await supabase
    .from("case_studies")
    .select("*")
    .eq("published", true)
    .order("created_at", { ascending: false });
  if (error || !data || data.length === 0) return FALLBACK_CASE_STUDIES;
  return data as unknown as CaseStudy[];
}

export async function getCaseStudyBySlug(slug: string): Promise<CaseStudy | null> {
  if (!SUPABASE_CONFIGURED) {
    return FALLBACK_CASE_STUDIES.find((c) => c.slug === slug) ?? null;
  }
  const supabase = createClient();
  const { data, error } = await supabase
    .from("case_studies")
    .select("*")
    .eq("slug", slug)
    .eq("published", true)
    .single();
  if (error || !data) return null;
  return data as unknown as CaseStudy;
}

export async function getCreativeWorks(): Promise<CreativeWork[]> {
  if (!SUPABASE_CONFIGURED) return [];
  const supabase = createClient();
  const { data, error } = await supabase
    .from("creative_works")
    .select("*")
    .eq("published", true)
    .order("created_at", { ascending: false });
  if (error || !data) return [];
  return data as unknown as CreativeWork[];
}

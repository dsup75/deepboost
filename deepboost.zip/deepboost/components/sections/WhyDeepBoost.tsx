"use client";

import { motion } from "framer-motion";

const PRINCIPLES = [
  { n: "01", title: "Creative That Converts", desc: "Every asset is built to earn attention and turn it into action." },
  { n: "02", title: "Data Before Guesswork", desc: "Decisions are grounded in campaign data, not assumptions." },
  { n: "03", title: "Fast Execution", desc: "Lean workflows mean strategy moves into market quickly." },
  { n: "04", title: "Continuous Optimization", desc: "Campaigns are tested and refined for compounding performance." },
];

export default function WhyDeepBoost() {
  return (
    <section className="section-pad border-t border-border bg-bg-secondary">
      <div className="container-max">
        <h2 className="max-w-2xl font-display text-4xl font-semibold leading-tight tracking-tight sm:text-5xl">
          NOT JUST MORE REACH.
          <br />
          <span className="bg-gradient-violet-cyan bg-clip-text text-transparent">MORE IMPACT.</span>
        </h2>

        <div className="mt-16 grid gap-px overflow-hidden rounded-2xl border border-border bg-border sm:grid-cols-2 lg:grid-cols-4">
          {PRINCIPLES.map((p, i) => (
            <motion.div
              key={p.n}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.08 }}
              className="bg-bg-secondary p-8"
            >
              <span className="font-display text-sm text-cyan">{p.n}</span>
              <h3 className="mt-4 font-display text-lg font-semibold">{p.title}</h3>
              <p className="mt-3 text-sm text-muted">{p.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

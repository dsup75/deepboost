import Hero from "@/components/sections/Hero";
import Metrics from "@/components/sections/Metrics";
import Services from "@/components/sections/Services";
import WhyDeepBoost from "@/components/sections/WhyDeepBoost";
import CaseStudies from "@/components/sections/CaseStudies";
import CreativeWorks from "@/components/sections/CreativeWorks";
import SocialSystem from "@/components/sections/SocialSystem";
import Process from "@/components/sections/Process";
import About from "@/components/sections/About";
import CTA from "@/components/sections/CTA";
import { getMetrics, getServices, getCaseStudies, getCreativeWorks } from "@/lib/data";

export default async function HomePage() {
  const [metrics, services, caseStudies, creativeWorks] = await Promise.all([
    getMetrics(),
    getServices(),
    getCaseStudies(),
    getCreativeWorks(),
  ]);

  return (
    <>
      <Hero />
      <Metrics metrics={metrics} />
      <Services services={services} />
      <WhyDeepBoost />
      <CaseStudies caseStudies={caseStudies} />
      <CreativeWorks works={creativeWorks} />
      <SocialSystem />
      <Process />
      <About />
      <CTA />
    </>
  );
}

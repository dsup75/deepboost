"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Plus, Trash2, Eye, EyeOff } from "lucide-react";
import { createClient } from "@/lib/supabase/client";
import type { Service } from "@/types";

export default function ServicesListPage() {
  const [items, setItems] = useState<Service[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    setLoading(true);
    const supabase = createClient();
    const { data } = await supabase.from("services").select("*").order("order");
    setItems((data as unknown as Service[]) ?? []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  async function toggle(id: string, value: boolean) {
    const supabase = createClient();
    await supabase.from("services").update({ published: value }).eq("id", id);
    setItems((prev) => prev.map((i) => (i.id === id ? { ...i, published: value } : i)));
  }

  async function remove(id: string) {
    if (!confirm("Delete this service permanently?")) return;
    const supabase = createClient();
    await supabase.from("services").delete().eq("id", id);
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  return (
    <div className="p-6 md:p-10">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h1 className="font-display text-2xl font-semibold">Services</h1>
          <p className="mt-1 text-sm text-muted">Homepage service cards, in display order.</p>
        </div>
        <Link href="/admin/services/new" className="btn-primary"><Plus size={16} /> New Service</Link>
      </div>

      <div className="mt-6 overflow-x-auto rounded-xl border border-border">
        <table className="w-full text-left text-sm">
          <thead className="bg-bg-secondary text-muted">
            <tr>
              <th className="px-4 py-3 font-medium">Order</th>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium" />
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={4} className="px-4 py-8 text-center text-muted">Loading...</td></tr>
            ) : items.length === 0 ? (
              <tr><td colSpan={4} className="px-4 py-8 text-center text-muted">No services yet.</td></tr>
            ) : (
              items.map((s) => (
                <tr key={s.id} className="border-t border-border">
                  <td className="px-4 py-3">{s.order}</td>
                  <td className="px-4 py-3"><Link href={`/admin/services/${s.id}`} className="hover:text-cyan">{s.name}</Link></td>
                  <td className="px-4 py-3">
                    <span className={`rounded-full px-2 py-0.5 text-xs ${s.published ? "bg-cyan/15 text-cyan" : "bg-white/10 text-muted"}`}>
                      {s.published ? "Published" : "Draft"}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-3 text-muted">
                      <button onClick={() => toggle(s.id, !s.published)}>{s.published ? <Eye size={15} /> : <EyeOff size={15} />}</button>
                      <button onClick={() => remove(s.id)} className="hover:text-red-400"><Trash2 size={15} /></button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import Link from "next/link";
import { createClient } from "@/lib/supabase/client";
import { TextField, TextAreaField, ToggleField, SelectField } from "@/components/admin/FormField";
import type { Service } from "@/types";

const ICONS = ["target", "palette", "share2", "trending-up", "layers"];

const EMPTY: Omit<Service, "id" | "created_at" | "updated_at"> = {
  name: "",
  slug: "",
  description: "",
  features: [],
  icon: "target",
  visual_3d: null,
  order: 0,
  featured: true,
  published: true,
};

function slugify(input: string) {
  return input.toLowerCase().trim().replace(/[^a-z0-9]+/g, "-").replace(/(^-|-$)/g, "");
}

export default function ServiceEditPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const isNew = params.id === "new";

  const [form, setForm] = useState(EMPTY);
  const [featuresText, setFeaturesText] = useState("");
  const [loading, setLoading] = useState(!isNew);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (isNew) return;
    async function load() {
      const supabase = createClient();
      const { data } = await supabase.from("services").select("*").eq("id", params.id).single();
      if (data) {
        setForm(data as unknown as Service);
        setFeaturesText(((data as unknown as Service).features || []).join(", "));
      }
      setLoading(false);
    }
    load();
  }, [isNew, params.id]);

  function set<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSave() {
    setSaving(true);
    const supabase = createClient();
    const payload = {
      ...form,
      slug: form.slug || slugify(form.name),
      features: featuresText.split(",").map((f) => f.trim()).filter(Boolean),
    };

    if (isNew) {
      const { data, error } = await supabase.from("services").insert(payload).select().single();
      setSaving(false);
      if (!error && data) router.push(`/admin/services/${data.id}`);
    } else {
      await supabase.from("services").update(payload).eq("id", params.id);
      setSaving(false);
      setForm(payload);
    }
  }

  async function handleDelete() {
    if (isNew || !confirm("Delete this service permanently?")) return;
    const supabase = createClient();
    await supabase.from("services").delete().eq("id", params.id);
    router.push("/admin/services");
  }

  if (loading) return <div className="p-10 text-muted">Loading...</div>;

  return (
    <div className="p-6 md:p-10">
      <Link href="/admin/services" className="text-sm text-muted hover:text-text">← All Services</Link>
      <h1 className="mt-4 font-display text-2xl font-semibold">{isNew ? "New Service" : form.name}</h1>

      <div className="mt-6 grid gap-8 lg:grid-cols-[2fr_1fr]">
        <div className="space-y-5">
          <TextField label="Service Name" value={form.name} onChange={(v) => set("name", v)} required />
          <TextField label="Slug" value={form.slug} onChange={(v) => set("slug", v)} placeholder="auto-generated if left blank" />
          <TextAreaField label="Description" value={form.description} onChange={(v) => set("description", v)} />
          <TextAreaField label="Features (comma-separated)" value={featuresText} onChange={setFeaturesText} rows={3} />
          <SelectField label="Icon" value={form.icon} onChange={(v) => set("icon", v)} options={ICONS} />
          <TextField label="Order" value={String(form.order)} onChange={(v) => set("order", Number(v) || 0)} />
        </div>

        <div className="space-y-5">
          <div className="card-surface space-y-4 p-5">
            <ToggleField label="Featured" value={form.featured} onChange={(v) => set("featured", v)} />
            <ToggleField label="Published" value={form.published} onChange={(v) => set("published", v)} />
          </div>
          <div className="flex flex-col gap-3">
            <button onClick={handleSave} disabled={saving} className="btn-primary justify-center">
              {saving ? "Saving..." : "Save"}
            </button>
            {!isNew && (
              <button onClick={handleDelete} className="rounded-full border border-red-500/30 px-6 py-3 text-sm font-semibold text-red-400 hover:bg-red-500/10">
                Delete
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

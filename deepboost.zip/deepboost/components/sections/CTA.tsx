"use client";

import Link from "next/link";
import { motion } from "framer-motion";

export default function CTA() {
  return (
    <section className="section-pad border-t border-border">
      <div className="container-max relative overflow-hidden rounded-3xl border border-border bg-card px-8 py-20 text-center">
        <div className="pointer-events-none absolute left-1/2 top-0 h-72 w-[600px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-gradient-violet-cyan opacity-20 blur-[120px]" />
        <motion.h2
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mx-auto max-w-2xl font-display text-4xl font-semibold leading-tight tracking-tight sm:text-5xl"
        >
          Ready to build your
          <br />
          next growth story?
        </motion.h2>
        <p className="mx-auto mt-5 max-w-md text-muted">
          Tell us what you&apos;re building. We&apos;ll figure out how to make it grow.
        </p>
        <Link href="/contact" className="btn-primary mx-auto mt-8 w-fit">
          Start a Project <span aria-hidden>→</span>
        </Link>
      </div>
    </section>
  );
}

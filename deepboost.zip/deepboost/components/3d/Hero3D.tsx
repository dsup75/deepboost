"use client";

import dynamic from "next/dynamic";
import { useEffect, useState } from "react";

const GrowthVisual = dynamic(() => import("./GrowthVisual"), {
  ssr: false,
  loading: () => <FallbackVisual />,
});

function supportsWebGL() {
  try {
    const canvas = document.createElement("canvas");
    return !!(
      window.WebGLRenderingContext &&
      (canvas.getContext("webgl") || canvas.getContext("experimental-webgl"))
    );
  } catch {
    return false;
  }
}

function FallbackVisual() {
  return (
    <div className="relative flex h-full w-full items-center justify-center">
      <div className="absolute h-72 w-72 animate-glow rounded-full bg-gradient-violet-cyan opacity-25 blur-[90px] md:h-96 md:w-96" />
      <div className="relative h-56 w-56 animate-float rounded-3xl border border-white/10 bg-gradient-to-br from-violet/20 to-cyan/10 backdrop-blur-sm md:h-72 md:w-72">
        <div className="absolute inset-6 rounded-2xl border border-white/10" />
        <div className="absolute inset-12 rounded-xl border border-white/10" />
      </div>
    </div>
  );
}

export default function Hero3D() {
  const [ready, setReady] = useState<"loading" | "webgl" | "fallback">("loading");

  useEffect(() => {
    const prefersReduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (prefersReduced || !supportsWebGL()) {
      setReady("fallback");
    } else {
      setReady("webgl");
    }
  }, []);

  if (ready === "loading") return <FallbackVisual />;
  if (ready === "fallback") return <FallbackVisual />;
  return <GrowthVisual />;
}
